<?php
$conn = mysqli_connect('localhost', 'root','', 'login');
	if  (isset ($_POST['login_btn']))
 {	
$name = $_POST['name'];
$father = $_POST['father'];
$post = $_POST['post'];
$postal = $_POST['postal'];
$sex = $_POST['sex'];
$city = $_POST['city'];
$course = $_POST['course'];
$district = $_POST['district'];
$pincode = $_POST['pincode'];
$email = $_POST['email'];
$dob = $_POST['dob'];
$mobile = $_POST['mobile'];

	   
	$sql = "INSERT INTO student( name, father, post, postal, sex, city, course, district, pincode, email, dob, mobile) VALUES('$name', '$father', '$post', '$postal', '$sex', '$city', '$course', '$district', '$pincode', '$email', '$dob', '$mobile')";
	
	
 	//echo $sql;exit;
if (mysqli_query($conn, $sql)) 
{
	
	header("location: logout.php");
	}
else {
	

	echo "<script type='text/javascript'>alert('Invalid login...Please try again');
window.location='login.php' ; 
</script>";
	
	}	

	}

	?>






<html>
<head>
<link rel="stylesheet" type="text/css" href="style2.css">
<script type="text/javascript" src="validate.js"></script>
</head>
<body>
<form action = "StudentRegistration.php" method = "post" name="StudentRegistration" onsubmit="return(validate());">

<style type = "text/css">
td{
color:#fafad2;
font-style:bold;
font-size:20px;

}
</style>
<div class = "loginbox">
<table cellpadding="0" width="35%" bgcolor="" align="left"
cellspacing="0">

<tr>
<td colspan=2>
<center><font size=4><b>Student Registration Form</b></font></center>
</td>
</tr>

<tr>
<td>Name</td>
<td><input type=text name="name" size="30" required></td>
</tr>

<tr>
<td>Father Name</td>
<td><input type="text" name="father" size="30"required></td>
</tr>
<tr>
<td>Postal Address</td>
<td><input type="text" name="post" size="30" required></td>
</tr>

<tr>
<td>Personal Address</td>
<td><input type="text" name="postal" size="30" required></td>
</tr>

<tr>
<td>Sex</td>

<td><select name="sex" >
<option value="-1" selected>select..</option>
<option value="Male">MALE</option>
<option value="Female">FEMALE</option>
<option value="Other">OTHER</option>

</select></td>
</tr>
<tr>
<td>City</td>
<td><select name="city">
<option value="-1" selected>select..</option>
<option value="Erode">ERODE</option>
<option value="Madurai">MADURAI</option>
<option value="Covai">COVAi</option>
<option value="Salem">SAlEM</option>
</select></td>
</tr>

<tr>
<td>Course</td>
<td><select name="course" >
<option value="-1" selected>select..</option>
<option value="B.Tech">B.TECH</option>
<option value="MCA">MCA</option>
<option value="MBA">MBA</option>
<option value="BCA">BCA</option>
</select></td>
</tr>

<tr>
<td>District</td>
<td><select name="district">
<option value="-1" selected>select..</option>
<option value="ERODE">ERODE</option>
<option value="SALEM">SALEM</option>
<option value="COVAI">COVAI</option>
<option value="MADURAI">MADURAI</option>
</select></td>

</tr>

</tr>
<tr>
<td>PinCode</td>
<td><input type="text" name="pincode" size="30" required></td>

</tr>
<tr>
<td>EmailId</td>
<td><input type="text" name="email" size="30" required></td>
</tr>

<tr>
<td>DOB</td>
<td><input type="date" name="dob" size="30" required></td>
</tr>

<tr>
<td>MobileNo</td>
<td><input type="text" name="mobile" size="30" required></td>
</tr>
<tr>
<td><input type="reset"></td>
<td colspan="2"><input type="submit" name = "login_btn" value="login"></td>
</tr>
</table>
</div>
</form>
</body>
</html>




