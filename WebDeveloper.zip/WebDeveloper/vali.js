function vali()
{ 
   if( document.register.username.value == "" )
   {
     alert( "Please provide your Name!" );
     document.register.username.focus() ;
     return false;
   }
   if( document.register.email.value == "" )
   {
     alert( "Please provide your Father Name!" );
     document.register.email.focus() ;
     return false;
   }

	if( document.register.password.value == "" )
   {
     alert( "Please provide your Name!" );
     document.register.password.focus() ;
     return false;
   }
   if( document.register.password2.value == "" )
   {
     alert( "Please provide your Father Name!" );
     document.register.password2.focus() ;
     return false;
   }
   
   
  
   return( true );
}