-<?php
$conn = mysqli_connect('localhost', 'root','', 'login');
	if  (isset ($_POST['register_btn']))
 {	
	$username = $_POST['username'];
	   $email = $_POST['email'];
	   $password = $_POST['password'];
	$password2 = $_POST['password2'];
	 
if ($password == $password2) {
	   
	$sql = "INSERT INTO register( user, email, pass, repass) VALUES( '$username', '$email', '$password', '$password2')";
 	
if (mysqli_query($conn, $sql)) {
	echo "success";
	$_SESSION['message'] = " you are logged in";
	header("location: login.php");
	}
else {
	

	$_SESSION['message'] = "the two password do not match";
	
	}	

	}
}
	
?>





<!DOCTYPE html>
<html>
<head>
	<title> Registration </title>
<script type="text/javascript" src="vali.js"></script>

<link rel = "stylesheet"  type = " text/css"  href = "style.css">

<style type = "text/css">	
table td{

color:#ff9933;

}
</style>

</head>

<body>
<div class = "header">
	<h1>Registration </h1>
</div >
<form action="register.php" name="register" method = "post" onsubmit="return(vali());">
 
        <table>
	<tr>
	<td> Username: </td>
	<td> <input type = "text" name = "username" class = "textInput">  </td>
	</tr>

	<tr>
	<td> Email: </td>
	<td> <input type = "email" name = "email" class = "textInput">  </td>
	</tr>

	<tr>
	<td> Password: </td>
	<td> <input type = "password" name = "password" class = "textInput">  </td>
	</tr>

	<tr>
	<td> Password again : </td>
	<td> <input type = "Password" name = "password2" class = "textInput">  </td>
	</tr>

	<tr>
	<td> </td>
	<td> <input type = "submit"  name = "register_btn"  value = "Register" >  </td>
	</tr>
<a href="login.php"> Already account </a>
       </table>
</form>
</body>
