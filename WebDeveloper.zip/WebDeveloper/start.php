<?php
	
?>

<HTML>
<HEAD>
<TITLE>START</TITLE>
<STYLE>
P{

	color: ;
	font-size:35px;
}
H1{

	color: YELLOW;
}
H2{

	color: #8b0000;
	font-size:25;
}
BODY{
    width: 400px;
    height: 600px;
    background-color:PURPLE;
	background: url(648552.jpg);
    background-size: cover;
    background-position: center;
    color: #FFF;
    top: 50%;
    left: 50%;
    position: absolute;
      transform: translate(-50%,-50%);
    box-sizing: border-box;
    padding: 70px 30px;
}

P1{
    width: 100px;
    height: 100px;
    border-radius: 50%;
    position: absolute;
    top: -50px;
    left: calc(50% -50px);
}


</STYLE>


</HEAD><BODY ALIGN="CENTER" >
<P> REGISTRATION </P>
<P> </P>
<H1> <TR> <MARQUEE>  STUDENT REGISTRATION !!!!! </MARQUEE> </TR></H1> 
<A HREF ="register.php"> <H2>CLICK ON REGISTRATION PAGE</H2> </A>
</BODY>
</HTML>
