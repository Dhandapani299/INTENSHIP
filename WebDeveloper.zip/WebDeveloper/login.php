
<html>
<head>
<title>Login Form Design</title>
    <link rel="stylesheet" type="text/css" href="style1.css">

	<style type = "text/css">

	p{

	
	}

	</style>

</head>
<body>
   <div class="loginbox">
   <img src="avatar.png" class="avatar">
        <h1>Login Here</h1>
        <form method ="POST" action ="login.php">
            <p>Username</p>
            <input type="text" name="user" id="user"  placeholder="Enter Username">
            <p>Password</p>
            <input type="password" name="pass" id="pass"  placeholder="Enter Password">
            <input type="submit" name="Login" value="Login">            
           </form>
    </div>
</body>
</html>


<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "login";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";
if(@$_POST['Login']!="")
{
@$user = $_POST['user'];
@$pass = $_POST['pass'];
	//echo $uname."  ".$pwd;
$sql="SELECT * FROM register WHERE pass='$pass' AND user='$user'"; 
$result=$conn->query($sql);
if($result->num_rows > 0)
{
 header("location:StudentRegistration.php");
}
else
{
echo "<script type='text/javascript'>alert('Invalid login...Please try again');
window.location='login.php' ; 
</script>";
}
}
?>
