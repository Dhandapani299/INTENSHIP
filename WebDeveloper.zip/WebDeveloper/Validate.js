function validate()
{ 
   if( document.StudentRegistration.name.value == "" )
   {
     alert( "Please provide your Name!" );
     document.StudentRegistration.name.focus() ;
     return false;
   }
   if( document.StudentRegistration.father.value == "" )
   {
     alert( "Please provide your Father Name!" );
     document.StudentRegistration.father.focus() ;
     return false;
   }
   
   if( document.StudentRegistration.post.value == "" )
   {
     alert( "Please provide your Postal Address!" );
     document.StudentRegistration.post.focus() ;
     return false;
   }
   if( document.StudentRegistration.portal.value == "" )
   {
     alert( "Please provide your Personal Address!" );
     document.StudentRegistration.portal.focus() ;
     return false;
   }
    if( document.StudentRegistration.sex.value == "-1" )
   {
     alert( "Please provide your Personal Address!" );
     document.StudentRegistration.sex.focus() ;
     return false;
   }
   if( document.StudentRegistration.city.value == "-1" )
   {
     alert( "Please provide your City!" );
     document.StudentRegistration.city.focus() ;
     return false;
   }   
   if( document.StudentRegistration.course.value == "-1" )
   {
     alert( "Please provide your course!" );
    
     return false;
   }   
   if( document.StudentRegistration.district.value == "-1" )
   {
     alert( "Please provide your Select District!" );
    
     return false;
   }   
   
   if( document.StudentRegistration.pincode.value == "" ||
           isNaN( document.StudentRegistration.pincode.value) ||
           document.StudentRegistration.pincode.value.length != 6 )
   {
     alert( "Please provide a pincode in the format ######." );
     document.StudentRegistration.pincode.focus() ;
     return false;
   }
 var email = document.StudentRegistration.email.value;
  atpos = email.indexOf("@");
  dotpos = email.lastIndexOf(".");
 if (email == "" || atpos < 1 || ( dotpos - atpos < 2 )) 
 {
     alert("Please enter correct email ID")
     document.StudentRegistration.email.focus() ;
     return false;
 }
  if( document.StudentRegistration.dob.value == "" )
   {
     alert( "Please provide your DOB!" );
     document.StudentRegistration.dob.focus() ;
     return false;
   }
  if( document.StudentRegistration.mobile.value == "" ||
           isNaN( document.StudentRegistration.mobileno.value) ||
           document.StudentRegistration.mobile.value.length != 10 )
   {
     alert( "Please provide a Mobile No in the format 123." );
     document.StudentRegistration.mobile.focus() ;
     return false;
   }
   return( true );
}